#include <bits/stdc++.h>
#include "OneStop.cpp"
int main()
{

    OneStop s1;
    s1.StartSystem();

    return 0;
}