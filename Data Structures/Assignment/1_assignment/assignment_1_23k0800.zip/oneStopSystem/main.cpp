#include <bits/stdc++.h>
#include "OneStop.h"
int main()
{

    OneStop s1;
    s1.StartSystem();

    return 0;
}