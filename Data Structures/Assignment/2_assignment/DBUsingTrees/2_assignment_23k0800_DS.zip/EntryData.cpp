#include "EntryData.h"

EntryData::EntryData() : ID(0), name(""), age(0) {}
EntryData::EntryData(int id, string nam, int ag) : ID(id), name(nam), age(ag) {}
